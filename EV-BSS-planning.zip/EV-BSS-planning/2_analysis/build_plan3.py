
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import _path  # noqa: F401

from build_inventory import V3, v3_operations  # noqa: E402
from src import loaders, metrics  # noqa: E402
from src.loaders import output_dir, params  # noqa: E402
from src import provenance  # noqa: E402

def price_mixed(rec: pd.DataFrame, c: dict, elec_factor: float,
                diesel_factor: float, eta_c: float = 1.0,
                weighted: bool = False, lhv: float | None = None) -> float:
    """CNY/km under the charging plan's per-leg price rule."""
    swap, charge = c["swapping_price"], c["charging_price"]
    nm_to_km = c["nautical_mile_to_km"]
    lhv = c["diesel_lhv_kwh_per_litre"] if lhv is None else lhv
    unit, dist = [], []
    for _, g in rec.groupby("mmsi"):
        total, pending = 0.0, 0.0
        for _, r in g.iterrows():
            if r.feasible == 1:
                pending += r.energy
                if r.swapped == 1:
                    metered = pending * elec_factor / eta_c
                    total += metered * (swap if r.cargo_port == 1 else charge)
                    pending = 0.0
            else:
                if pending > 0:
                    total += pending * elec_factor / eta_c * charge
                    pending = 0.0
                shaft = r.energy * diesel_factor / c["diesel_combustion_efficiency"]
                total += shaft / lhv * c["diesel_price_per_litre"]
        if pending > 0:
            total += pending * elec_factor / eta_c * charge
        unit.append(total)
        dist.append(g.distance.sum())
    u, d = pd.Series(unit), pd.Series(dist)
    return float((u.sum() / d.sum() if weighted else (u / d).mean()) / nm_to_km)


def own_ports(seg: pd.DataFrame) -> dict:
    return {m: set(g.start) | set(g.end) for m, g in seg.groupby("mmsi")}


def paper_cargo_flag(mmsi, end, own: dict) -> list[int]:
    return [int(e in own[m]) for m, e in zip(mmsi, end)]


def v3_record(stations: list[str], cargo: str = "paper") -> pd.DataFrame:
    """Plan 2's operating record, in the column names this module prices."""
    ops = v3_operations(stations)
    ops = ops.rename(columns={"energy_kwh": "energy", "feasible": "feasible",
                              "optimised swapping": "swapped"})
    if cargo == "paper":
        own = own_ports(pd.read_csv(V3 / "segment_energy_v3.csv"))
        ops["cargo_port"] = paper_cargo_flag(ops.mmsi, ops.end, own)
    elif cargo == "heuristic":
        ops["cargo_port"] = 1
        seen = ops.groupby(["mmsi", "start", "end"]).cumcount()
        ops.loc[seen > 0, "cargo_port"] = 0
    elif cargo != "leg_end":
        raise ValueError(f"unknown cargo mode {cargo!r}")
    return ops


def archived_record(n: int) -> pd.DataFrame:
    a = loaders.siting_result(n, "plan3_flexible_charge", 0)
    inc = a.groupby("mmsi")["cumulative_energy_kwh"].diff()
    first = a.groupby("mmsi").head(1).index
    inc.loc[first] = a.loc[first, "cumulative_energy_kwh"]
    return pd.DataFrame(dict(mmsi=a.mmsi, start=a.start, end=a.end,
                             distance=a.distance, energy=inc,
                             feasible=a["feasible"], swapped=a["optimised swapping"],
                             cargo_port=a["call_port"]))


def replayed_v0_record(stations: list[str]) -> pd.DataFrame:
    import networkx as nx
    from resolve_siting import PORT_BIT, Router, TOPOLOGY, replay

    topo = pd.read_csv(TOPOLOGY)
    graph = nx.Graph()
    for _, r in topo.iterrows():
        graph.add_edge(r.start, r.end, distance=float(r.distance))
    router = Router(graph)
    seg = loaders.segments_with_energy()
    ships = loaders.ship_parameters().set_index("mmsi")
    mask = sum(PORT_BIT[p] for p in stations)

    rows = []
    for mmsi, grp in seg.groupby("mmsi", sort=True):
        legs = grp[["start", "end", "distance", "energy_kwh"]].to_dict("records")
        rows += replay(legs, "energy_kwh", float(ships.loc[mmsi, "rated_capacity_kwh"]),
                       mask, router, mmsi)
    return pd.DataFrame(rows).rename(columns={"energy_kwh": "energy"})


def check_cargo_semantics() -> None:
    seg = loaders.segments_with_energy()
    own = own_ports(seg)
    for n in (4, 8, 9):
        a = loaders.siting_result(n, "plan3_flexible_charge", 0)
        rebuilt = pd.Series(paper_cargo_flag(a.mmsi, a.end, own), index=a.index)
        ok = rebuilt == a["call_port"]
        f = a["feasible"] == 1
        rate = ok[f].mean()
        if n == 8:
            pass


def main(run: str = "v3_coefficient_correction") -> None:
    out = output_dir(run)
    c = params()["cost"]
    zeta_eta = (params()["energy"]["depth_of_discharge"]
                * params()["energy"]["utilisation_efficiency"])
    eta_c = params()["lcc"]["energy_transfer_efficiency"]
    archived_diesel = c["diesel_electric_to_mechanical_efficiency"] * c["diesel_transmission_efficiency"]
    stn = params()["case"]["plan2_stations_8"]

    check_cargo_semantics()

    rows = []
    for n in (4, 8, 9):
        pub = metrics.mixed_cost(n, 0)
        rows.append(dict(run="A control, reference record and flag, LHV 9.8", n_stations=n,
                         plan3=pub))
    ctrl4 = rows[0]["plan3"]
    assert abs(ctrl4 - 34.3) < 0.25, (
        f"control Plan 3 at N=4 is {ctrl4:.2f}, not the published 34.3 "
        f"(Fig 14); the price rule has drifted")

    arch8 = archived_record(8)
    same = price_mixed(arch8, c, 1.0, archived_diesel, 1.0, lhv=9.8)
    assert abs(same - rows[1]["plan3"]) < 1e-9, (
        f"price_mixed {same} != metrics.mixed_cost {rows[1]['plan3']}")

    rep0 = replayed_v0_record(stn)
    n_ev_arch = int((arch8.swapped == 1).sum())
    n_ev_rep = int((rep0.swapped == 1).sum())

    a2a = arch8.copy()
    a2a["swapped"] = rep0.swapped.values
    v_a2a = price_mixed(a2a, c, 1.0, archived_diesel, 1.0, lhv=9.8)

    a2b = a2a.copy()
    a2b["cargo_port"] = rep0.cargo_port.values
    v_a2 = price_mixed(a2b, c, 1.0, archived_diesel, 1.0, lhv=9.8)

    rows.append(dict(run="A2a reference record, replayed event set, flags unchanged", n_stations=8,
                     plan3=v_a2a))
    rows.append(dict(run="A2 reference record, replayed replenishment event set", n_stations=8,
                     plan3=v_a2))
    base = rows[1]["plan3"]

    rec = v3_record(stn)
    n_feas = int(rec.groupby("mmsi").feasible.max().sum())
    assert n_feas == 156, f"v3 record has {n_feas} feasible ships, expected 156"

    swaps = rec[(rec.swapped == 1) & (rec.feasible == 1)]
    for label, mode in [("previous heuristic cumcount()>0", "heuristic"),
                        ("replay   end==leg destination", "leg_end")]:
        other = v3_record(stn, cargo=mode)
        dis = int((swaps.cargo_port.values
                   != other.loc[swaps.index, "cargo_port"].values).sum())

    for label, ef, df_, ce in [
            ("B v3 energy_kwh+paper metering convention", 1.0, archived_diesel, 1.0),
            ("C v3+metering corrected, main result", zeta_eta, zeta_eta, eta_c)]:
        p3 = price_mixed(rec, c, ef, df_, ce)
        rows.append(dict(run=label, n_stations=8, plan3=p3))

    rec_heur = v3_record(stn, cargo="heuristic")
    rec_leg = v3_record(stn, cargo="leg_end")
    steps = [
        ("1 baseline, heuristic cargo port and fleet weighted + LHV 9.8)",
         dict(r=rec_heur, weighted=True, lhv=9.8)),
        ("2 aggregation only -> paper unweighted mean", dict(r=rec_heur, weighted=False, lhv=9.8)),
        ("3 then change LHV -> params   10.0", dict(r=rec_heur, weighted=False, lhv=10.0)),
        ("4 then change cargo_port -> replay   leg destination, session  12 delivered",
         dict(r=rec_leg, weighted=False, lhv=10.0)),
        ("5 then change cargo_port -> paper call_port semantics, main result",
         dict(r=rec, weighted=False, lhv=10.0)),
    ]
    prev, attrib = None, []
    for label, kw in steps:
        v = price_mixed(kw["r"], c, zeta_eta, zeta_eta, eta_c,
                        weighted=kw["weighted"], lhv=kw["lhv"])
        delta = "" if prev is None else f"  Delta {v - prev:+.4f} (x{v / prev:.4f})"
        attrib.append(dict(run=f"attribution {label}", n_stations=8, plan3=v))
        prev = v

    d = pd.DataFrame(rows + attrib)
    d.to_csv(out / "plan3_cost.csv", index=False)
    provenance.record(out / "plan3_cost.csv", script=__file__,
                      inputs=[V3 / "segment_energy_v3.csv"],
                      params_used={"cost": c, "zeta_eta": zeta_eta,
                                   "eta_c": eta_c, "stations": stn})


if __name__ == "__main__":
    main()
