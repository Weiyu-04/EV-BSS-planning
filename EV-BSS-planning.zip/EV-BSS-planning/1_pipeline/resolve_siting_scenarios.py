
from __future__ import annotations

import sys
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import _path  # noqa: F401  (adds every stage dir to sys.path)

from resolve_siting import (  # noqa: E402
    CANDIDATE_PORTS, PORT_BIT, FlatFleet, Router, TOPOLOGY, replay, sweep,
)
from src.loaders import RESULTS, output_dir, params, ship_parameters  # noqa: E402

V3 = RESULTS / "v3_coefficient_correction"


def main(run: str = "v3_coefficient_correction", energy_from: str | None = None,
         compare_with: str = "v2_flowfield_rebuild") -> None:
    out = output_dir(run)
    src = output_dir(energy_from) if energy_from else out
    counts = ([int(a) for a in sys.argv[1:]] if len(sys.argv) > 1
              else params()["case"]["station_counts"])
    growths = params()["case"]["growth_sweep"]

    topo = pd.read_csv(TOPOLOGY)
    graph = nx.Graph()
    for _, r in topo.iterrows():
        graph.add_edge(r.start, r.end, distance=float(r.distance))
    router = Router(graph)

    d = pd.read_csv(src / "segment_energy_v3.csv")
    ships = ship_parameters().set_index("mmsi")

    ship_legs, battery = [], []
    for mmsi, grp in d.groupby("mmsi", sort=True):
        ship_legs.append(grp[["start", "end", "distance",
                              "energy_v2", "energy_new"]].to_dict("records"))
        battery.append(float(ships.loc[mmsi, "rated_capacity_kwh"]))
    battery = np.asarray(battery, float)

    rows = []
    for growth in growths:
        bat = battery * (1 + growth / 100.0)
        flat = FlatFleet(ship_legs, "energy_new")
        for n in counts:
            rows += [dict(r, growth=growth) for r in
                     sweep(ship_legs, "energy_new", bat, router, flat, n,
                           f"v3 growth{growth}")]

    v3 = pd.DataFrame(rows)
    v3.to_csv(out / "coverage_v3.csv", index=False)

    v2 = pd.read_csv(RESULTS / compare_with / "coverage_resolved.csv")
    v2 = v2[v2.source == "rebuilt energy"].set_index(["n_stations", "plan"])
    base = v3[v3.growth == 0].set_index(["n_stations", "plan"])

    for (n, plan) in sorted(base.index):
        if (n, plan) in v2.index:
            a, b = int(v2.loc[(n, plan), "covered"]), int(base.loc[(n, plan), "covered"])

    piv = v3.pivot_table(index=["n_stations", "plan"], columns="growth",
                         values="covered")
    piv.columns = [f"growth {c}%" for c in piv.columns]

    for growth in growths:
        r = v3[(v3.growth == growth) & (v3.n_stations == 8)
               & (v3.plan == "plan2")].iloc[0]

    r0 = v3[(v3.growth == 0) & (v3.n_stations == 8) & (v3.plan == "plan2")].iloc[0]
    mask = sum(PORT_BIT[p] for p in r0.stations.split("|"))
    mmsis = sorted(d.mmsi.unique())
    ops = pd.DataFrame([row for s, legs in enumerate(ship_legs)
                        for row in replay(legs, "energy_new", battery[s], mask,
                                          router, mmsis[s])])
    ops.to_csv(out / "operations_8stn_v3.csv", index=False)


if __name__ == "__main__":
    main()
