# Battery swapping station planning for inland electric ships

Code and parameters behind the paper *Swapping Station Planning Framework for
Battery Electric Ships Considering Flexible Battery Swapping and Analysis of
Battery Inventory Changing* (eTransportation, manuscript ETRAN-D-26-00296).

This repository is published so that a reader can see how each result was
computed. It is a curated copy of the internal working tree, with the internal
quality gates, the figure scripts and the writing toolchain left out.

## What is here

| Path | Paper section | What it does |
|---|---|---|
| `src/profile.py` | 3.2.2 | Lateral velocity profile, Equations (1) and (2) |
| `src/geometry.py` | 3.2.3 | Normal projection and the lateral coordinate, Equations (3) to (5) |
| `s2_flowfield/run.py` | 3.2 | Builds the flow field over the corridor |
| `1_pipeline/calibrate_flow_field.py` | 3.2.2, 4.1.3 | Anchors the section-mean velocity on the gauge record |
| `1_pipeline/rebuild_flow_velocities.py` | 3.2.4 | Section-mean velocity per leg |
| `src/metrics.py` | 3.3.4 | Admiralty power and leg energy, Equations (6) to (8) |
| `1_pipeline/calibrate_admiralty_pership.py` | 3.3.4, 4.1.3 | Coefficient per ship from the power regression |
| `s3_energy/run.py` | 3.3 | Energy for every voyage leg |
| `2_analysis/build_soc.py` | 3.4.2 | State of charge per leg, Equations (15a) and (15b) |
| `1_pipeline/resolve_siting.py` | 3.4 | Fixed-size maximum coverage over station combinations |
| `s4_siting/run.py` | 3.4, 4.2, 4.3.1 | Coverage and the selected stations |
| `1_pipeline/rebuild_inventory_chain.py` | 3.5.3 | Daily station inventory, Equations (22) to (26) |
| `src/timechain.py` | 4.3.2 | Port time chain from arrival to departure |
| `2_analysis/build_transfer_model.py` | 3.5, 4.4 | Inter-port transfer inside the plan |
| `s5_inventory/run.py` | 3.5, 4.4 | Opening inventory under both swapping modes |
| `2_analysis/build_lcc.py` | 3.6, Appendix G | Life-cycle cost, the nine items |
| `s6_cost/run.py` | 3.6, 4.3.3 | Cost per kilometer for the four plans |
| `2_analysis/build_uncertainty.py` | 4.5.1 | Perturbed runs, fixed seed |
| `2_analysis/build_queueing.py` | 4.5.2 | Service capacity and waiting |
| `s7_robustness/run.py` | 4.5 | Robustness of the planning solution |
| `s8_release/run.py` | 4.1.3 | Builds the shared voyage-level table |
| `params.yaml` | Appendix A, Appendix G | Every parameter with its value and its source |

## Data

`data/voyages.csv` is the voyage-level table the study runs on. One row per
leg, with a stable code in place of the vessel identity and English port
names. The table is pseudonymised rather than anonymous. A reader with access
to commercial AIS could in principle match a route back to a vessel.

The raw AIS records are licensed from a commercial provider and are not
shared in any form. Appendix A of the paper reports every preprocessing
parameter and every exclusion criterion, which is what the review asked for.

## Parameters

`params.yaml` is the single source for every constant. Each entry carries its
value and where the value comes from. Entries marked `assumed` have no citable
source and are swept in the sensitivity analysis rather than presented as
measured.

## Reading order

Start at `params.yaml`, then follow the table above from Section 3.2 downward.
Each `run.py` is the entry point for one section of the paper and loads the
modules listed beside it.
